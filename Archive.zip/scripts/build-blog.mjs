#!/usr/bin/env node
import { readFileSync, readdirSync, mkdirSync, writeFileSync, rmSync, existsSync } from 'node:fs';
import path from 'node:path';
import { marked } from 'marked';
import matter from 'gray-matter';

const ROOT = path.resolve(import.meta.dirname, '..');
const CONTENT_DIR = path.join(ROOT, 'content/blog');
const OUTPUT_DIR = path.join(ROOT, 'public/blog');
const escapeHtml = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const slugify = (s) => String(s).toLowerCase().trim().replace(/[^a-z0-9\s-]/g, '').replace(/[\s_]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
const formatDate = (d) => new Date(`${d}T00:00:00Z`).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' });

const page = ({ title, description, body }) => `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#040a30">
  <meta name="description" content="${escapeHtml(description)}">
  <title>${escapeHtml(title)}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/styles.css">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header wrap">
  <a class="brand" href="/" aria-label="Not Only Artificial home"><span class="brand-mark">NOA</span><span class="brand-name">Not Only<br>Artificial</span></a>
  <nav aria-label="Main navigation"><a href="/blog/">Journal</a><a href="/approach/">Our approach</a><a href="mailto:hello@notonlyartificial.com" class="nav-cta">Say hello <span aria-hidden="true">↗</span></a></nav>
</header>
${body}
<footer class="site-footer wrap"><span>© 2026 Not Only Artificial</span><a href="mailto:hello@notonlyartificial.com">Say hello ↗</a><span>Thoughtful technology. Human intent.</span></footer>
<script src="/script.js"></script>
</body>
</html>
`;

const meta = (p) => `<span class="blog-meta"><span>${escapeHtml(p.category)}</span><time datetime="${escapeHtml(p.date)}">${formatDate(p.date)}</time><span>${p.readingMinutes} min read</span></span>`;
const postCard = (p, heading = 'h2') => `
    <article class="blog-card">
      <a href="/blog/${p.slug}/">
        <img class="blog-image" src="${escapeHtml(p.image)}" alt="" width="1200" height="800" loading="lazy" decoding="async">
        <div class="card-copy">
          ${meta(p)}
          <${heading}>${escapeHtml(p.title)}</${heading}>
          <p>${escapeHtml(p.excerpt)}</p>
          <span class="blog-read">Read the essay <span aria-hidden="true">↗</span></span>
        </div>
      </a>
    </article>`;

function loadPosts() {
  if (!existsSync(CONTENT_DIR)) return [];
  return readdirSync(CONTENT_DIR)
    .filter((f) => f.endsWith('.md'))
    .map((filename) => {
      const { data, content } = matter(readFileSync(path.join(CONTENT_DIR, filename), 'utf8'));
      const body = content.replace(/^\s*#[^\n]*\n+/, '');
      const text = body.replace(/[#*_`>[\]!-]/g, ' ').replace(/\s+/g, ' ').trim();
      // Images are local editorial assets; reject remote or traversal paths.
      const image = typeof data.image === 'string' && /^\/assets\/[a-zA-Z0-9_-]+\.(webp|png|jpg)$/.test(data.image)
        ? data.image : '/assets/research.webp';
      return {
        slug: slugify(data.slug || filename.replace(/\.md$/, '')),
        title: data.title || filename.replace(/\.md$/, ''),
        date: data.date instanceof Date ? data.date.toISOString().slice(0, 10) : data.date ? String(data.date).slice(0, 10) : '1970-01-01',
        excerpt: data.excerpt || data.description || text.slice(0, 160) + (text.length > 160 ? '…' : ''),
        category: data.category || 'Perspectives',
        image,
        featured: data.featured === true,
        readingMinutes: Math.max(1, Math.ceil(text.split(/\s+/).length / 220)),
        draft: !!data.draft,
        html: marked.parse(body),
      };
    })
    .filter((post) => !post.draft)
    .sort((a, b) => b.date.localeCompare(a.date));
}

function replaceRegion(html, name, body) {
  const start = `<!-- ${name}:START -->`;
  const end = `<!-- ${name}:END -->`;
  const startIdx = html.indexOf(start);
  const endIdx = html.indexOf(end);
  if (startIdx === -1 || endIdx < startIdx) throw new Error(`Missing homepage region: ${name}`);
  return html.slice(0, startIdx + start.length) + '\n' + body + '\n    ' + html.slice(endIdx);
}

function build() {
  const posts = loadPosts();
  rmSync(OUTPUT_DIR, { recursive: true, force: true });
  mkdirSync(OUTPUT_DIR, { recursive: true });
  writeFileSync(path.join(OUTPUT_DIR, 'index.html'), page({
    title: 'Journal — Not Only Artificial',
    description: 'Independent thinking on AI, human judgment, and what comes next.',
    body: `<main id="main" class="reading-surface"><div class="wrap">
  <section class="blog-hero"><p class="eyebrow">The journal</p><h1>Notes on AI,<br>done right.</h1><p>Ideas on people, technology, and a more thoughtful future.</p></section>
  <section class="blog-list" aria-label="All articles">${posts.length ? posts.map(p => postCard(p)).join('\n') : '<p class="blog-empty">No posts yet — check back soon.</p>'}</section>
</div></main>`,
  }));
  for (const p of posts) {
    const dir = path.join(OUTPUT_DIR, p.slug);
    mkdirSync(dir, { recursive: true });
    writeFileSync(path.join(dir, 'index.html'), page({
      title: `${p.title} — Not Only Artificial`, description: p.excerpt,
      body: `<main id="main" class="reading-surface"><div class="wrap"><article class="post">
  <header class="post-header"><a class="text-link" href="/blog/">← The journal</a>${meta(p)}<h1>${escapeHtml(p.title)}</h1><p class="post-deck">${escapeHtml(p.excerpt)}</p><img class="post-cover" src="${escapeHtml(p.image)}" alt="" width="1200" height="800"></header>
  <div class="post-content">${p.html}</div>
  <a class="button secondary back-link" href="/blog/">← All articles</a>
</article></div></main>`,
    }));
  }
  const indexPath = path.join(ROOT, 'public/index.html');
  let html = readFileSync(indexPath, 'utf8');
  html = replaceRegion(html, 'BLOG_PREVIEW', posts.slice(0, 3).map(p => postCard(p, 'h3')).join('\n') || '<p class="blog-empty">No posts yet — check back soon.</p>');
  const featured = posts.find(p => p.featured) || posts[0];
  html = replaceRegion(html, 'FEATURED_POST', featured ? `<a class="featured-post" href="/blog/${featured.slug}/"><span class="featured-label">01 / Featured essay</span><strong>${escapeHtml(featured.title)}</strong><span class="circle-arrow" aria-hidden="true">↗</span></a>` : '');
  writeFileSync(indexPath, html);
  console.log(`[blog] built ${posts.length} post(s) and homepage previews`);
}
build();
